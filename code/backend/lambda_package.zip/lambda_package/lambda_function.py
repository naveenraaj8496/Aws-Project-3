import json
import pymssql
import os
import base64
import xlsxwriter
import io
import boto3
from datetime import datetime, date
from botocore.exceptions import ClientError
 
def get_db_credentials(secret_name):
    """
    Retrieve database credentials from AWS Secrets Manager.
    """
    region_name = os.environ.get('AWS_REGION', 'ap-south-1')
    client = boto3.client('secretsmanager', region_name=region_name)
 
    try:
        response = client.get_secret_value(SecretId=secret_name)
        secret_dict = json.loads(response['SecretString'])
        # Debug: print retrieved keys
        print("Retrieved secret keys:", list(secret_dict.keys()))
        return secret_dict
    except ClientError as e:
        print(f"Secrets Manager error: {e}")
        raise Exception(f"Unable to retrieve database credentials: {e}")
    except json.JSONDecodeError as e:
        print(f"Error parsing secret JSON: {e}")
        raise Exception(f"Secret string is not valid JSON: {e}")
 
def lambda_handler(event, context):
    secret_name = os.environ.get('DB_SECRET_NAME', 'my-sqlserver-credentials')
    creds = get_db_credentials(secret_name)
 
    # Safely get credentials, provide defaults if missing
    server   = creds.get('host')
    database = creds.get('dbname')
    username = creds.get('username')
    password = creds.get('password')
    port     = creds.get('port')
 
 
    if not all([server, database, username, password]):
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': 'Database credentials missing or incomplete',
                'details': list(creds.keys())
            })
        }
 
    # Get query parameters
    empid = name = download = None
    if event.get('body'):
        try:
            body = json.loads(event['body'])
            empid = body.get('empid', '').strip()
            name = body.get('name', '').strip()
            download = body.get('download')
        except Exception as e:
            print(f"Error parsing body: {e}")
    if event.get('queryStringParameters'):
        qs = event['queryStringParameters']
        empid = empid or qs.get('empid', '').strip()
        name = name or qs.get('name', '').strip()
        download = download or qs.get('download')
 
    connection = None
    try:
        connection = pymssql.connect(
            server=server,
            user=username,
            password=password,
            database=database,
            port=int(port) if port else 1433
        )
        cursor = connection.cursor()
 
        base_query = """
        SELECT empid, name, department, position, email, phone, hire_date
        FROM employeeData
        """
        
        where_conditions = []
        parameters = []
 
        if empid:
            where_conditions.append("empid = %s")
            parameters.append(empid)
        if name:
            where_conditions.append("name LIKE %s")
            parameters.append(f"%{name}%")
        
        query = base_query
        if where_conditions:
            query += " WHERE " + " AND ".join(where_conditions)
        query += " ORDER BY empid"
 
        cursor.execute(query, tuple(parameters))
        columns = [col[0] for col in cursor.description]
        rows = cursor.fetchall()
 
        data = []
        for row in rows:
            employee = {}
            for i, col in enumerate(columns):
                value = row[i]
                if isinstance(value, (datetime, date)):
                    employee[col] = value.isoformat()
                elif value is None:
                    employee[col] = ""
                else:
                    employee[col] = str(value)
            data.append(employee)
 
        # Excel download
        if download == 'excel':
            output = io.BytesIO()
            workbook = xlsxwriter.Workbook(output, {'in_memory': True})
            worksheet = workbook.add_worksheet('Employee Data')
 
            header_format = workbook.add_format({
                'bold': True,
                'bg_color': '#4472C4',
                'font_color': 'white',
                'border': 1
            })
            headers = ['Employee ID', 'Name', 'Department', 'Position', 'Email', 'Phone', 'Hire Date']
            for col_num, header in enumerate(headers):
                worksheet.write(0, col_num, header, header_format)
                worksheet.set_column(col_num, col_num, 20)
 
            data_format = workbook.add_format({'border': 1})
            for row_num, employee in enumerate(data, start=1):
                worksheet.write(row_num, 0, employee.get('empid', ''), data_format)
                worksheet.write(row_num, 1, employee.get('name', ''), data_format)
                worksheet.write(row_num, 2, employee.get('department', ''), data_format)
                worksheet.write(row_num, 3, employee.get('position', ''), data_format)
                worksheet.write(row_num, 4, employee.get('email', ''), data_format)
                worksheet.write(row_num, 5, employee.get('phone', ''), data_format)
                worksheet.write(row_num, 6, employee.get('hire_date', ''), data_format)
 
            workbook.close()
            output.seek(0)
            excel_data = base64.b64encode(output.read()).decode()
 
            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                    'Content-Disposition': 'attachment; filename="employee_data.xlsx"',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
                },
                'body': excel_data,
                'isBase64Encoded': True
            }
 
        # Default JSON response
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
            },
            'body': json.dumps(data)
        }
 
    except pymssql.Error as db_err:
        print(f"Database error: {db_err}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Database connection error', 'details': str(db_err)})
        }
    except Exception as e:
        print(f"General error: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Internal server error', 'details': str(e)})
        }
    finally:
        if connection:
            connection.close()
 